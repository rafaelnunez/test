import { request } from "@alegradev/smile-ui-alegra"

export function getUser() {
  return request({
    url: "v1/users/self",
    method: "GET"
  })
}

export async function getFakeData() {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve({ data: "Fake Data" })
    }, 2000)
  })
}

// or, use async / await if you want to treat your data
// export async function getUser() {
//   try {
//     const { data } = await request({
//       url: "v1/users/self",
//       method: "GET"
//     })
//     if (data) {
//       return data.map(...)
//     }
//     return "No user found"
//   } catch (e) {
//     throw e
//   }
// }
