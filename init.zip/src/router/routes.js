// import Default from "../views/Default.vue"

const routes = [
  // {
  //   path: "/",
  //   name: "Default",
  //   component: Default
  // },
  {
    path: "/",
    redirect: "/default"
  },
  {
    path: "/default",
    name: "default",
    // route level code-splitting, this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "Default" */ "../views/Default.vue")
  },
  {
    path: "/client/view/id/:id",
    name: "client-view",
    component: () =>
      import(/* webpackChunkName: "default-test-view" */ "../views/DefaultTestView.vue")
  },
  {
    path: "/item/view/id/:id",
    name: "item-view",
    component: () =>
      import(/* webpackChunkName: "default-test-view" */ "../views/DefaultTestView.vue")
  }
]

export default routes
