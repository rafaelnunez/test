<template>
  <div>
    Default Test View
  </div>
</template>

<script>
export default {
  name: "DefaultTestView",
  metaInfo: {
    title: "Other Title"
  }
}
</script>

<style lang="scss" scoped></style>
