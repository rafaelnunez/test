<template>
  <div>
    <default-component />
  </div>
</template>

<script>
import DefaultComponent from "@/components/Default/Default"
export default {
  name: "Default",
  metaInfo() {
    return { title: this.$trans("defaultPage.title", "Loading...") }
  },
  components: {
    DefaultComponent
  }
}
</script>

<style lang="scss" scoped></style>
