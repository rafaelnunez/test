// mutations
const mutations = {
  INC: state => {
    state.counter++
  },
  INC_BY: (state, { ammount }) => {
    state.counter += ammount
  },
  DEC: (state, ammount = 1) => {
    state.counter -= ammount
  },
  STORE_RESULT: (state, data) => {
    state.data = data
  }
}

export default mutations
