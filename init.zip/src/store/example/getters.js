// getters
const getters = {
  counterPlus2: state => state.counter * 2
}

export default getters
