import { getFakeData } from "@/api/example"

// Actions should allways return a Promise
const actions = {
  // Example:
  inc({ commit }) {
    return new Promise(resolve => {
      commit("INC")
      resolve()
    })
  },
  incBy({ commit }, ammount) {
    return new Promise(resolve => {
      commit("INC_BY", { ammount })
      resolve()
    })
  },
  // Example with async operations
  asyncOperation({ commit }) {
    return new Promise(async (resolve, reject) => {
      try {
        // Calling mutation from another module 'app'
        commit("app/LOADING_INC", null, { root: true })
        // Async operation 1
        const { data } = await getFakeData()
        // Async operation 2
        const result = await getFakeData()

        // do something...
        const res = { msg1: data, msg2: result }
        commit("STORE_RESULT", res)
        resolve()
      } catch (e) {
        // console.log(e)
        reject(e)
      } finally {
        commit("app/LOADING_DEC", null, { root: true })
      }
    })
  },
  dec({ commit }) {
    return new Promise(resolve => {
      commit("DEC")
      resolve()
    })
  },
  // Example returning api Promise directly
  decAsync({ commit }) {
    // getFakeData returns a Promise
    return getFakeData().then(result => {
      commit("DEC", result)
    })
  }
}

export default actions
