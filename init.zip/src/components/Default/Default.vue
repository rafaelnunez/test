<template>
  <div class="container">
    <sm-heading>
      Default Page
    </sm-heading>
    <sm-card class="mt-sm">
      <sm-paragraph>Translate test: {{ $trans("defaultPage.title") }}</sm-paragraph>
      <sm-paragraph>
        Dynamically added translate: {{ $transF("translateDynamicTest", "Cargando traducción...") }}
      </sm-paragraph>
      <sm-paragraph>Big.js test: {{ test }}</sm-paragraph>
      <sm-paragraph>counter: {{ counter }}</sm-paragraph>
      <sm-paragraph>counterPlus2: {{ counterPlus2 }}</sm-paragraph>
      <div>
        <sm-button :loading="isAppLoading" @click="inc">
          INC
        </sm-button>
        &nbsp;&nbsp;
        <sm-button :loading="isAppLoading" primary @click="dec">
          DEC
        </sm-button>
      </div>
      <hr />
      <sm-button ghost :loading="isAppLoading" @click="asyncOperation">
        Async op
      </sm-button>
      <sm-paragraph>Async op result: {{ dataFromExample }} </sm-paragraph>
    </sm-card>
  </div>
</template>

<script>
import Big from "big.js"
import { mapState, mapGetters, mapActions } from "vuex"

export default {
  name: "defaultComponent",
  props: {
    isWidget: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      test: 0
    }
  },
  computed: {
    ...mapState("example", {
      counter: state => state.counter,
      dataFromExample: state => state.data
    }),
    ...mapGetters({
      counterPlus2: "example/counterPlus2",
      isAppLoading: "app/loading"
    })
  },
  mounted() {
    this.test = Big(0.5).plus(Big(0.2))

    setTimeout(() => {
      this.$store.dispatch("app/addToDictionary", {
        translateDynamicTest: "Traducción agragada dinamicamente",
        pageTitle: "Default Page"
      })
    }, 2000)
  },
  methods: {
    ...mapActions("example", ["inc", "dec"]),
    async asyncOperation() {
      this.result = await this.$store.dispatch("example/asyncOperation")
    }
  }
}
</script>

<style lang="scss" scoped>
.container {
  margin-left: 2em;
  margin-right: 2em;
}
// deeply nested selector
::v-deep .mt-sm {
  margin-top: 1em;
}
</style>
