export default {
  defaultPage: {
    title: "Hello world from en/common.js"
  }
}
