<template>
  <default-component :is-widget="true" />
</template>

<script>
import DefaultComponent from "../components/Default/Default"
export default {
  name: "DefaultWidget",
  components: {
    DefaultComponent
  }
}
</script>

<style lang="scss" scoped></style>
